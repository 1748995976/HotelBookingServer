#直接将文件在D：盘下解压即可，也可以在其它文件任何目录下解压，但需要自行配置后端文件位置
#由于有些开源库存在问题，我们需要自行替换aar文件，将压缩包中的citypicker-2.0.3.arr文件替换
C:\Users\***\.gradle\caches\modules-2\files-2.1\com.zaaach\citypicker\2.0.3\ 下其中某一文件夹下的citypicker-2.0.3.arr文件（***代表你的用户目录名）
#有三个账户用于登录
账号：1	密码：1
账号：111111	密码：111111
账号：111112	密码：111112

客户端开发环境：Android Studio版本4.1.1
#在logic/network/MyServiceCreator中配置IP地址和监听端口，监听端口可以保持默认，IP地址要修改

后端开发环境：在Visual Studio Code上配置基本的Node.js运行环境
#在app.js文件中446行（靠近文件底部）可以配置监听的端口号
#文件所在的位置需要配置好，在app.js文件中32行（靠近文件头部）来配置图片所在的路径
#配置正确后在主目录下执行指令node app.js即可

数据库管理：使用Navicat Premium 15连接MySQL进行管理
#字符集：utf8mb4
#排序规则：utf8mb4_0900_ai_ci

GitHub地址：https://github.com/1748995976?tab=repositories
#毕业设计结束之后仓库会公开
