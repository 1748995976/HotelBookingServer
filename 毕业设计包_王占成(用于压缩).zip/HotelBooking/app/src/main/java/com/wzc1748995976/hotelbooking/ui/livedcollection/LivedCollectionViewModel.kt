package com.wzc1748995976.hotelbooking.ui.livedcollection

import androidx.lifecycle.ViewModel

class LivedCollectionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}