package com.wzc1748995976.hotelbooking.logic.model

data class LoginResponse(val status: Int,val result: Boolean)
