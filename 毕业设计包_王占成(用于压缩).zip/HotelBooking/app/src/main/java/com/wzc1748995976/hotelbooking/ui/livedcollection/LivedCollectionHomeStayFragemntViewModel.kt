package com.wzc1748995976.hotelbooking.ui.livedcollection

import androidx.lifecycle.ViewModel

class LivedCollectionHomeStayFragemntViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}