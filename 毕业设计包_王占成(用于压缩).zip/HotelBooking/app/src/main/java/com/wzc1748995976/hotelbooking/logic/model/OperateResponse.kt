package com.wzc1748995976.hotelbooking.logic.model

data class OperateResponse(val status: Int, val data: Boolean)