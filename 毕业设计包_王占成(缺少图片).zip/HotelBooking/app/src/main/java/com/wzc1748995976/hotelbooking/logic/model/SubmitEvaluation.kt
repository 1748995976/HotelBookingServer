package com.wzc1748995976.hotelbooking.logic.model

class SubmitEvaluation (
    val orderId:String,
    val account:String,val hotelId: String,val eid:String,
    val score:String,val evaluation: String,val checkInDate:String,
    val anonymous:Int
)